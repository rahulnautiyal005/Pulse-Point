import React from 'react';

const App = () => {
    return (
        <div>
            <h1>Welcome to the Healthcare App</h1>
        </div>
    );
};

export default App;
